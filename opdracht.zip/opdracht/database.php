<?php
$user= 'root';
$pass = '';
$db_conn = new PDO('mysql:host=localhost;dbname=phpexpert', $user, $pass);
?>
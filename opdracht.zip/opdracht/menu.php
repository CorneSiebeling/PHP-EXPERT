<ul class="nav justify-content-center ">

    <li class="nav-item">
        <a class="nav-link" href="superheroes_index.php">Superheroes</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="superheroes_create.php">maak heroes</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="categories_index.php">categories</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="catogerie_create.php">maak categorie</a>
    </li>

</ul>